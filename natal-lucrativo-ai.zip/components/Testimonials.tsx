import React from 'react';
import { Icons } from './Icons';

const personas = [
  {
    name: "O Indeciso",
    quote: "Eu? Nada! Todo ano fico perdido. Não sei por onde começo...",
    type: "Antes",
    color: "bg-gray-100",
    icon: <Icons.Users className="text-gray-500" />
  },
  {
    name: "O Tradicional",
    quote: "Esse ano vai ser diferente. Vou fazer meu peru clássico seguindo o e-book.",
    type: "Depois",
    color: "bg-green-50",
    borderColor: "border-green-200",
    icon: <Icons.ChefHat className="text-green-600" />
  },
  {
    name: "O Inovador",
    quote: "Gosto de inovar! Vou fazer um pernil com tempero especial que aprendi.",
    type: "Depois",
    color: "bg-blue-50",
    borderColor: "border-blue-200",
    icon: <Icons.Sparkles className="text-blue-600" />
  },
  {
    name: "A Empreendedora",
    quote: "Eu uso o e-book pra vender ceias! Já virou minha renda extra.",
    type: "Sucesso",
    color: "bg-yellow-50",
    borderColor: "border-yellow-200",
    icon: <Icons.DollarSign className="text-yellow-600" />
  }
];

const Testimonials: React.FC = () => {
  return (
    <section className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-800">
            Qual é o seu <span className="text-red-600">Perfil de Natal</span>?
          </h2>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {personas.map((p, idx) => (
            <div key={idx} className={`p-6 rounded-xl border ${p.borderColor || 'border-gray-200'} ${p.color} relative`}>
              <div className="absolute -top-4 left-6 bg-white p-2 rounded-full shadow-sm border border-gray-100">
                {p.icon}
              </div>
              <div className="mt-6">
                <h3 className="font-bold text-gray-900 mb-1">{p.name}</h3>
                <span className="text-xs font-semibold uppercase tracking-wide text-gray-500 mb-4 block">{p.type}</span>
                <p className="text-gray-700 italic text-sm leading-relaxed">"{p.quote}"</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;