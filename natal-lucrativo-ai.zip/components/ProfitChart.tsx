import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';

interface ProfitChartProps {
  cost: number;
  sale: number;
}

const ProfitChart: React.FC<ProfitChartProps> = ({ cost, sale }) => {
  const profit = sale - cost;
  const data = [
    { name: 'Custo', amount: cost, color: '#ef4444' }, // red-500
    { name: 'Venda', amount: sale, color: '#3b82f6' }, // blue-500
    { name: 'Lucro', amount: profit, color: '#22c55e' }, // green-500
  ];

  return (
    <div className="h-64 w-full bg-white p-4 rounded-lg shadow-sm border border-gray-100">
      <h4 className="text-center font-bold text-gray-700 mb-4">Simulação de Lucro</h4>
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data}>
          <CartesianGrid strokeDasharray="3 3" vertical={false} />
          <XAxis dataKey="name" axisLine={false} tickLine={false} />
          <YAxis hide />
          <Tooltip 
            formatter={(value: number) => [`R$ ${value.toFixed(2)}`, 'Valor']}
            cursor={{fill: 'transparent'}}
          />
          <Bar dataKey="amount" radius={[4, 4, 0, 0]}>
            {data.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={entry.color} />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
      <p className="text-xs text-center text-gray-500 mt-2">
        *Estimativa baseada nos preços médios
      </p>
    </div>
  );
};

export default ProfitChart;