import { 
  ChefHat, 
  DollarSign, 
  Clock, 
  BookOpen, 
  Users, 
  Star, 
  ArrowRight,
  CheckCircle2,
  Utensils,
  Sparkles
} from 'lucide-react';

export const Icons = {
  ChefHat,
  DollarSign,
  Clock,
  BookOpen,
  Users,
  Star,
  ArrowRight,
  CheckCircle2,
  Utensils,
  Sparkles
};