import React from 'react';
import { Icons } from './Icons';

const CTA: React.FC = () => {
  return (
    <section className="bg-gray-900 text-white py-20">
      <div className="container mx-auto px-4 text-center">
        <div className="max-w-3xl mx-auto">
            <h2 className="text-4xl md:text-5xl font-serif font-bold mb-6 text-yellow-400">
                Ceia Fácil • Receita Garantida • Renda Extra
            </h2>
            <p className="text-xl text-gray-300 mb-10 leading-relaxed">
                Se você quer uma ceia deliciosa, prática e organizada... ou até ganhar dinheiro vendendo ceias... esse e-book é pra você.
            </p>
            
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                <button className="w-full sm:w-auto bg-red-600 hover:bg-red-500 text-white font-bold text-lg px-10 py-5 rounded-full shadow-red-900/50 shadow-lg transition-transform hover:scale-105 flex items-center justify-center">
                    <Icons.BookOpen className="w-6 h-6 mr-3" />
                    Quero o Natal Lucrativo
                </button>
            </div>
            
            <div className="mt-12 grid grid-cols-2 md:grid-cols-4 gap-4 text-sm text-gray-400">
                <div className="flex items-center justify-center"><Icons.CheckCircle2 className="w-4 h-4 mr-2 text-green-500"/> Acesso Imediato</div>
                <div className="flex items-center justify-center"><Icons.CheckCircle2 className="w-4 h-4 mr-2 text-green-500"/> 7 Dias de Garantia</div>
                <div className="flex items-center justify-center"><Icons.CheckCircle2 className="w-4 h-4 mr-2 text-green-500"/> Compra Segura</div>
                <div className="flex items-center justify-center"><Icons.CheckCircle2 className="w-4 h-4 mr-2 text-green-500"/> Suporte Exclusivo</div>
            </div>
        </div>
      </div>
    </section>
  );
};

export default CTA;