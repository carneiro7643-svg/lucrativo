import React from 'react';
import { Icons } from './Icons';

interface HeroProps {
  onStart: () => void;
}

const Hero: React.FC<HeroProps> = ({ onStart }) => {
  return (
    <section className="relative bg-gradient-to-b from-red-700 to-red-900 text-white overflow-hidden">
      {/* Decorative elements */}
      <div className="absolute top-0 left-0 w-full h-full opacity-10 pointer-events-none">
        <div className="absolute top-10 left-10 transform rotate-45">
            <Icons.Sparkles size={64} />
        </div>
        <div className="absolute bottom-20 right-20 transform -rotate-12">
            <Icons.ChefHat size={128} />
        </div>
      </div>

      <div className="container mx-auto px-4 py-20 md:py-32 relative z-10 flex flex-col items-center text-center">
        <div className="inline-flex items-center bg-white/20 backdrop-blur-sm px-4 py-1 rounded-full mb-6 animate-fade-in-up">
          <Icons.Clock className="w-4 h-4 mr-2 text-yellow-300" />
          <span className="text-sm font-medium uppercase tracking-wider">Faltam poucos dias para o Natal!</span>
        </div>

        <h1 className="text-4xl md:text-6xl font-bold mb-6 leading-tight animate-fade-in-up" style={{ animationDelay: '0.1s' }}>
          Você já decidiu como vai ser<br />
          <span className="text-yellow-400">sua ceia de Natal?</span>
        </h1>

        <p className="text-xl md:text-2xl text-red-100 max-w-2xl mb-8 animate-fade-in-up" style={{ animationDelay: '0.2s' }}>
          Chega de correria e improviso. Tenha uma ceia deliciosa, organizada e lucrativa.
        </p>

        <div className="flex flex-col sm:flex-row gap-4 animate-fade-in-up" style={{ animationDelay: '0.3s' }}>
          <button 
            onClick={onStart}
            className="bg-yellow-500 hover:bg-yellow-400 text-red-900 font-bold text-lg px-8 py-4 rounded-full shadow-lg transition-transform transform hover:scale-105 flex items-center justify-center"
          >
            Planejar Minha Ceia Agora
            <Icons.ArrowRight className="ml-2 w-5 h-5" />
          </button>
        </div>
      </div>
      
      {/* Wave Divider */}
      <div className="absolute bottom-0 w-full overflow-hidden leading-[0]">
        <svg className="relative block w-[calc(130%+1.3px)] h-[60px]" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 120" preserveAspectRatio="none">
            <path d="M321.39,56.44c58-10.79,114.16-30.13,172-41.86,82.39-16.72,168.19-17.73,250.45-.39C823.78,31,906.67,72,985.66,92.83c70.05,18.48,146.53,26.09,214.34,3V0H0V27.35A600.21,600.21,0,0,0,321.39,56.44Z" className="fill-white"></path>
        </svg>
      </div>
    </section>
  );
};

export default Hero;