import React from 'react';
import { Icons } from './Icons';

const Features: React.FC = () => {
  const features = [
    {
      icon: <Icons.Utensils className="w-8 h-8 text-red-600" />,
      title: "Receitas Completas",
      description: "Do Peru clássico ao Pernil inovador, tudo testado e aprovado."
    },
    {
      icon: <Icons.CheckCircle2 className="w-8 h-8 text-red-600" />,
      title: "Lista de Compras",
      description: "Saiba exatamente o que comprar para evitar desperdícios."
    },
    {
      icon: <Icons.Clock className="w-8 h-8 text-red-600" />,
      title: "Cronograma",
      description: "Passo a passo de horários para não ficar na cozinha a noite toda."
    },
    {
      icon: <Icons.DollarSign className="w-8 h-8 text-red-600" />,
      title: "Planilhas Automáticas",
      description: "Calcule o preço de venda e lucro em segundos."
    }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-4">
            O E-book <span className="text-red-600">Completíssimo</span>
          </h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Eu conferi, e ele tem tudo o que você precisa para transformar seu Natal.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((f, idx) => (
            <div key={idx} className="bg-gray-50 p-8 rounded-2xl hover:shadow-xl transition-shadow border border-gray-100 text-center group">
              <div className="bg-red-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:bg-red-200 transition-colors">
                {f.icon}
              </div>
              <h3 className="text-xl font-bold text-gray-800 mb-3">{f.title}</h3>
              <p className="text-gray-600">{f.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Features;