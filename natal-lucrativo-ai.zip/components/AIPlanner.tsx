import React, { useState, useCallback } from 'react';
import { generateChristmasPlan } from '../services/geminiService';
import { PlanGoal, BudgetLevel, MenuPlan } from '../types';
import { Icons } from './Icons';
import ProfitChart from './ProfitChart';

const AIPlanner: React.FC = () => {
  const [step, setStep] = useState<'form' | 'loading' | 'result'>('form');
  const [goal, setGoal] = useState<PlanGoal>(PlanGoal.FAMILY);
  const [budget, setBudget] = useState<BudgetLevel>(BudgetLevel.MEDIUM);
  const [people, setPeople] = useState<number>(4);
  const [plan, setPlan] = useState<MenuPlan | null>(null);

  const handleGenerate = useCallback(async () => {
    setStep('loading');
    const generatedPlan = await generateChristmasPlan(goal, budget, people);
    if (generatedPlan) {
      setPlan(generatedPlan);
      setStep('result');
    } else {
      setStep('form');
      alert("Ocorreu um erro ao gerar o plano. Verifique sua API Key ou tente novamente.");
    }
  }, [goal, budget, people]);

  const reset = () => {
    setStep('form');
    setPlan(null);
  };

  if (step === 'loading') {
    return (
      <div id="planner" className="min-h-[400px] flex flex-col items-center justify-center bg-gray-900 text-white rounded-2xl p-8">
        <Icons.Sparkles className="w-12 h-12 text-yellow-400 animate-spin mb-4" />
        <h3 className="text-2xl font-bold mb-2">A Inteligência Artificial está planejando...</h3>
        <p className="text-gray-400">Consultando o método "Natal Lucrativo"...</p>
      </div>
    );
  }

  if (step === 'result' && plan) {
    return (
      <div id="planner" className="bg-white rounded-2xl shadow-2xl overflow-hidden border border-gray-200">
        <div className="bg-red-700 text-white p-6 flex justify-between items-center">
          <div>
            <h3 className="text-2xl font-bold font-serif">{plan.title}</h3>
            <p className="text-red-100 text-sm">Planejado para {people} pessoas • Orçamento {budget === BudgetLevel.HIGH ? 'Alto' : budget === BudgetLevel.MEDIUM ? 'Médio' : 'Econômico'}</p>
          </div>
          <button onClick={reset} className="text-white hover:bg-red-800 p-2 rounded-full transition-colors">
            <Icons.Clock className="w-5 h-5" /> <span className="text-xs">Reiniciar</span>
          </button>
        </div>

        <div className="p-6 grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Menu Column */}
          <div className="lg:col-span-2 space-y-6">
            <div>
              <h4 className="flex items-center font-bold text-gray-800 mb-3 border-b pb-2">
                <Icons.Utensils className="w-5 h-5 mr-2 text-red-600" /> O Cardápio
              </h4>
              <div className="bg-gray-50 p-4 rounded-lg space-y-3">
                <div className="flex justify-between border-b border-dashed border-gray-200 pb-2">
                  <span className="font-medium text-gray-600">Entradas</span>
                  <span className="text-gray-800 text-right">{plan.starters.join(', ')}</span>
                </div>
                <div className="flex justify-between border-b border-dashed border-gray-200 pb-2">
                  <span className="font-medium text-gray-600">Prato Principal</span>
                  <span className="text-gray-800 font-bold text-right">{plan.mainCourse}</span>
                </div>
                <div className="flex justify-between border-b border-dashed border-gray-200 pb-2">
                  <span className="font-medium text-gray-600">Acompanhamentos</span>
                  <span className="text-gray-800 text-right">{plan.sides.join(', ')}</span>
                </div>
                <div className="flex justify-between">
                  <span className="font-medium text-gray-600">Sobremesa</span>
                  <span className="text-gray-800 font-bold text-right">{plan.dessert}</span>
                </div>
              </div>
            </div>

            <div>
              <h4 className="flex items-center font-bold text-gray-800 mb-3 border-b pb-2">
                <Icons.CheckCircle2 className="w-5 h-5 mr-2 text-green-600" /> Top 5 Lista de Compras
              </h4>
              <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {plan.shoppingList.map((item, i) => (
                  <li key={i} className="flex items-center text-sm text-gray-700 bg-green-50 px-3 py-2 rounded">
                    <div className="w-2 h-2 bg-green-500 rounded-full mr-2"></div>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Strategy Column */}
          <div className="bg-gray-900 text-white p-6 rounded-xl flex flex-col justify-between">
            <div>
              <h4 className="flex items-center font-bold text-yellow-400 mb-4">
                <Icons.Star className="w-5 h-5 mr-2" /> Dica do Especialista
              </h4>
              <p className="text-gray-300 italic text-sm leading-relaxed mb-6">
                "{plan.profitTip}"
              </p>

              {plan.estimatedSalePrice > 0 && (
                <div className="mb-6">
                  <ProfitChart cost={plan.estimatedCost} sale={plan.estimatedSalePrice} />
                </div>
              )}

              {!plan.estimatedSalePrice && (
                 <div className="bg-white/10 p-4 rounded-lg mb-6">
                    <span className="block text-xs text-gray-400 uppercase">Custo Estimado</span>
                    <span className="text-2xl font-bold text-white">R$ {plan.estimatedCost.toFixed(2)}</span>
                 </div>
              )}
            </div>
            
            <button className="w-full bg-yellow-500 hover:bg-yellow-400 text-gray-900 font-bold py-3 rounded-lg transition-colors flex items-center justify-center">
               <Icons.BookOpen className="w-5 h-5 mr-2" />
               Baixar E-book Completo
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <section id="planner" className="py-20 container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
            <div className="text-center mb-10">
                <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-4">Planeje seu <span className="text-red-600">Natal na Prática</span></h2>
                <p className="text-gray-600">Use nossa IA para gerar uma prévia do que você encontra no e-book.</p>
            </div>

            <div className="bg-white p-8 rounded-2xl shadow-xl border border-gray-200">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                    <div>
                        <label className="block text-sm font-bold text-gray-700 mb-2">Qual seu objetivo?</label>
                        <div className="flex gap-2">
                            <button 
                                onClick={() => setGoal(PlanGoal.FAMILY)}
                                className={`flex-1 py-3 rounded-lg border transition-all ${goal === PlanGoal.FAMILY ? 'bg-red-100 border-red-500 text-red-700 font-bold' : 'border-gray-300 text-gray-500 hover:bg-gray-50'}`}
                            >
                                Família
                            </button>
                            <button 
                                onClick={() => setGoal(PlanGoal.PROFIT)}
                                className={`flex-1 py-3 rounded-lg border transition-all ${goal === PlanGoal.PROFIT ? 'bg-yellow-100 border-yellow-500 text-yellow-800 font-bold' : 'border-gray-300 text-gray-500 hover:bg-gray-50'}`}
                            >
                                Renda Extra
                            </button>
                        </div>
                    </div>

                    <div>
                        <label className="block text-sm font-bold text-gray-700 mb-2">Orçamento</label>
                        <select 
                            value={budget} 
                            onChange={(e) => setBudget(e.target.value as BudgetLevel)}
                            className="w-full p-3 rounded-lg border border-gray-300 bg-white focus:ring-2 focus:ring-red-500 focus:border-transparent"
                        >
                            <option value={BudgetLevel.LOW}>Econômico</option>
                            <option value={BudgetLevel.MEDIUM}>Moderado</option>
                            <option value={BudgetLevel.HIGH}>Sofisticado</option>
                        </select>
                    </div>

                    <div>
                        <label className="block text-sm font-bold text-gray-700 mb-2">Pessoas</label>
                        <input 
                            type="number" 
                            min={2} 
                            max={50}
                            value={people}
                            onChange={(e) => setPeople(parseInt(e.target.value))}
                            className="w-full p-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-red-500 focus:border-transparent"
                        />
                    </div>
                </div>

                <button 
                    onClick={handleGenerate}
                    className="w-full bg-red-600 hover:bg-red-700 text-white font-bold text-xl py-4 rounded-xl shadow-lg transition-transform transform hover:scale-[1.02] flex items-center justify-center"
                >
                    <Icons.Sparkles className="w-6 h-6 mr-2" />
                    Gerar Minha Ceia com IA
                </button>
                <p className="text-center text-xs text-gray-500 mt-4">
                    *Esta é uma demonstração gratuita baseada na metodologia do e-book.
                </p>
            </div>
        </div>
    </section>
  );
};

export default AIPlanner;