import { GoogleGenAI, Type, Schema } from "@google/genai";
import { PlanGoal, BudgetLevel, MenuPlan } from "../types";

const apiKey = process.env.API_KEY || '';
const ai = new GoogleGenAI({ apiKey });

const responseSchema: Schema = {
  type: Type.OBJECT,
  properties: {
    title: { type: Type.STRING, description: "A catchy name for this Christmas Menu" },
    starters: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
      description: "List of appetizers"
    },
    mainCourse: { type: Type.STRING, description: "The main protein or dish" },
    sides: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
      description: "Side dishes"
    },
    dessert: { type: Type.STRING, description: "The dessert" },
    estimatedCost: { type: Type.NUMBER, description: "Estimated raw material cost in BRL" },
    estimatedSalePrice: { type: Type.NUMBER, description: "Suggested selling price in BRL (0 if purely family goal)" },
    profitTip: { type: Type.STRING, description: "A specific tip from the 'Natal Lucrativo' methodology about efficiency or profit." },
    shoppingList: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
      description: "Top 5-7 key ingredients to buy"
    }
  },
  required: ["title", "starters", "mainCourse", "sides", "dessert", "estimatedCost", "estimatedSalePrice", "profitTip", "shoppingList"]
};

export const generateChristmasPlan = async (
  goal: PlanGoal,
  budget: BudgetLevel,
  peopleCount: number
): Promise<MenuPlan | null> => {
  if (!apiKey) {
    console.error("API Key is missing");
    return null;
  }

  const prompt = `
    Act as the expert author of the 'Natal Lucrativo na Prática' e-book.
    Create a custom Christmas Dinner plan.
    
    Context:
    - Goal: ${goal === PlanGoal.PROFIT ? 'Make Money Selling Dinners (Renda Extra)' : 'Family Dinner (Conexão Emocional)'}
    - Budget Level: ${budget}
    - Number of People: ${peopleCount}
    
    Tone: Professional, encouraging, practical.
    Locale: Brazil (Use BRL currency values and Brazilian culinary context).
    
    If the goal is PROFIT, focus on high-margin, easy-to-scale recipes (like Pernil or specialized Turkey).
    If the goal is FAMILY, focus on comfort, flavor, and "sem estresse" (stress-free).
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: responseSchema,
        temperature: 0.7
      }
    });

    if (response.text) {
      return JSON.parse(response.text) as MenuPlan;
    }
    return null;
  } catch (error) {
    console.error("Gemini API Error:", error);
    return null;
  }
};